# Task 1 Model Answer :bear:
Model answer for task 1 of the Telstra backend Forage program
